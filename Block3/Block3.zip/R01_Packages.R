#### Packages - Block 3 
#
install.packages(c("ggplot2","RColorBrewer","dplyr","reshape2","tidyr"), dependencies = T)
#
install.packages(c("sf","sp","rgdal","rgeos","eurostat","gstat","RCzechia"), dependencies = T)
#
install.packages(c("spdep","splm","spatialreg","raster"), dependencies = T)
# 
install.packages("spmoran", dependencies = T)
#