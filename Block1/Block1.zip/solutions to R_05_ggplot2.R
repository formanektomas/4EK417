### ggplot Assignment solutions
#
# 1
ggplot(small) + 
  geom_point(aes(x=carat,y=price,colour=cut)) + 
  facet_wrap(~cut, nrow=3) + # number of columns set
  ggtitle("Price ~ carat plot example") 
#
#
#
# 2
ggplot(small, aes(x=carat,y=price))+ 
  geom_point(aes(colour=cut))+
  ggtitle("Price ~ carat plot example")+
  facet_wrap(~cut, ncol=1)+
  geom_smooth(method= "lm",se=F) # new layer - linear trend
#
#
#
# 3
ggplot(small, aes(x=carat,y=price))+ 
  geom_point(aes(colour=cut))+
  ggtitle("Price ~ carat plot example")+
  #facet_wrap(~cut, ncol=1)+
  geom_smooth(method= "lm",se=F) # new layer - linear trend





ggplot(small, aes(x=carat,y=price, colour = cut) ) + 
  geom_point() + # "blue" colour removed
  geom_smooth(method= "lm") + # "lm" line-colours inherited from top level
  facet_wrap(~cut) + 
  scale_y_continuous(trans = "log") +
  ggtitle("Price ~ carat plot example") 
#
#
#
#
# 3
## 
## Use the "mtcars" datafile from the base {datasets} package.
## 1) Display basic data info into console
?mtcars
head(mtcars)
summary(mtcars)
str(mtcars)
## Use ggplot2 for the following tasks:
## 2) Make a histogram of "hp" (Gross horsepower)
ggplot(mtcars) + 
  geom_histogram(aes(x=hp))
## 3) Expand 2) by showing "am" (transmission) composition of each bin
mtcars$am <- as.factor(mtcars$am)
ggplot(mtcars) +
  geom_histogram(aes(x=hp, fill=am))
## 4) Make a scatterplot of "mpg" ~ "wt" (Miles/Gallon as a function of car Weight)
ggplot(mtcars) + 
  geom_point(aes(x=wt,y=mpg)) 
## 5) Add Title & lm regression line to plot 4)
ggplot(mtcars, aes(x=wt,y=mpg) ) + # sets default mapping for geom_ commands
  geom_point() +
  geom_smooth(method= "lm") +
  ggtitle("Plot example") 
## 6) Expand 5) by faceting along "am" (automatic/manual transmission)
ggplot(mtcars, aes(x=wt,y=mpg) ) + # sets default mapping for geom_ commands
  geom_point() +
  geom_smooth(method= "lm") +
  ggtitle("Plot example") +
  facet_wrap(~am) 
## 7) Amend 6) by using "theme_minimal
ggplot(mtcars, aes(x=wt,y=mpg) ) + # sets default mapping for geom_ commands
  geom_point() +
  geom_smooth(method= "lm") +
  ggtitle("Plot example") +
  facet_wrap(~am) +
  theme_minimal()


# Piechart of "cut" occurences
Data1 <- t(table(small$cut)/nrow(small))
Data1 <- t(Data1)
Data1 <- as.data.frame(Data1)
str(Data1)
#
ggplot(Data1, aes(x = "", y = Freq, fill = Var1)) +
  geom_bar(stat = "identity")+
  coord_polar(theta = "y")
