#### Econometric seminar ####
#
# Packages - Week 7
#
#
install.packages("ggplot2", dependencies = T)
#
install.packages("gridExtra", dependencies = T)
#
install.packages("plm", dependencies = T)
#
install.packages("car", dependencies = T)
#
install.packages("lmtest", dependencies = T)
#
install.packages("nlme", dependencies = T)
#
install.packages("foreign", dependencies = T)
#
install.packages("lattice", dependencies = T)
#
install.packages("lme4", dependencies = T)
#
install.packages("MEMSS", dependencies = T)
#
install.packages("bife", dependencies = T)
#
install.packages("knitr", dependencies = T)
#
install.packages("RLRsim", dependencies = T)
#
install.packages("dplyr", dependencies = T)
#
install.packages("Ecdat", dependencies = T)
#
install.packages("sjstats", dependencies = T)