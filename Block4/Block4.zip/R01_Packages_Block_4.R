#### Econometric seminar ####
#
# Packages - Block 4
#
#
install.packages(c("knitr","gridExtra","ggplot2","dplyr"), dependencies = T)
#
install.packages(c("lattice","foreign","Ecdat","car","lmtest"), dependencies = T)
#
install.packages(c("RLRsim","MEMSS","bife","sjstats","lme4","nlme","plm"), dependencies = T)
