#### Econometric seminar ####
#
# Packages - Week 1 
#
#
install.packages(c("ggplot2","dplyr","tidyr"), dependencies = T)
#
install.packages("ISLR", dependencies = T)
#
install.packages("markdown", dependencies = T)
#
install.packages("yaml", dependencies = T)
#
install.packages("knitr", dependencies = T)
#
install.packages("qtl", dependencies = T)
#
install.packages("WDI", dependencies = T)
#
install.packages("countrycode", dependencies = T)
#
install.packages("tidyverse", dependencies = T)